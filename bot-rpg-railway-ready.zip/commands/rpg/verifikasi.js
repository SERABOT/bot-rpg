const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
let db = require('../../database.json');
function saveDatabase() {
  fs.writeFileSync('./database.json', JSON.stringify(db, null, 2));
}
module.exports = {
  data: new SlashCommandBuilder()
    .setName('verifikasi')
    .setDescription('Verifikasi akunmu dengan kode dari DM')
    .addStringOption(option =>
      option.setName('kode')
        .setDescription('Kode dari DM')
        .setRequired(true)),
  async execute(interaction) {
    const userId = interaction.user.id;
    const inputKode = interaction.options.getString('kode');
    if (!db[userId] || !db[userId].hasStarted) {
      return interaction.reply({ content: '❌ Kamu belum memulai! Gunakan `/mulai`.', ephemeral: true });
    }
    if (db[userId].verified) {
      return interaction.reply({ content: '✅ Kamu sudah diverifikasi!', ephemeral: true });
    }
    if (inputKode !== db[userId].verify_code) {
      return interaction.reply({ content: '❌ Kode salah! Cek DM atau ulangi `/mulai`.', ephemeral: true });
    }
    db[userId].verified = true;
    delete db[userId].verify_code;
    saveDatabase();
    const embed = new EmbedBuilder()
      .setTitle('🛡️ Verifikasi Berhasil!')
      .setDescription(`
🎟️ Kode **${inputKode}** diterima.
📖 Namamu tercatat di Kitab Petualang.

Gunakan \`/main\` untuk menjelajah dunia fantasy!
`)
      .setColor('#2ecc71');
    await interaction.reply({ embeds: [embed] });
  }
};
