const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
let db = require('../../database.json');
function saveDatabase() {
  fs.writeFileSync('./database.json', JSON.stringify(db, null, 2));
}
module.exports = {
  data: new SlashCommandBuilder()
    .setName('mulai')
    .setDescription('Memulai petualanganmu di dunia fantasy!'),
  async execute(interaction) {
    const userId = interaction.user.id;
    if (db[userId]) {
      return interaction.reply({ content: '⚠️ Kamu sudah memulai petualangan! Gunakan `/main` untuk melanjutkan.', ephemeral: true });
    }
    const kodeVerifikasi = Math.floor(1000 + Math.random() * 9000).toString();
    db[userId] = {
      hasStarted: true,
      verified: false,
      verify_code: kodeVerifikasi,
      coin: 100,
      item: ['🪓 Pedang Kayu'],
      level: 1
    };
    saveDatabase();
    try {
      await interaction.user.send(
        `📜 Gulungan sihir bersinar...

**Selamat datang, ${interaction.user.username}**
🔐 Kode: \`/verifikasi ${kodeVerifikasi}\``
      );
    } catch (e) {
      console.warn(`❌ Tidak bisa kirim DM ke ${interaction.user.username}`);
    }
    const embed = new EmbedBuilder()
      .setTitle('✨ Petualangan Dimulai!')
      .setDescription(`
📨 Kamu menerima:
- 🪙 100 Koin
- 🪓 Pedang Kayu
- 🔐 Kode Verifikasi (cek DM)

Gunakan \`/verifikasi [kode]\` untuk mulai bermain!
`)
      .setColor('#f39c12');
    await interaction.reply({ embeds: [embed] });
  }
};
